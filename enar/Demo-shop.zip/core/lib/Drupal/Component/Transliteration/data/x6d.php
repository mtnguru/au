<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'pan', 'jie', 'yi', 'hui', 'hui', 'zai', 'cheng', 'yin', 'wei', 'hou', 'jian', 'yang', 'lie', 'si', 'ji', 'er',
  0x10 => 'xing', 'fu', 'sa', 'se', 'zhi', 'yin', 'wu', 'xi', 'kao', 'zhu', 'jiang', 'luo', 'luo', 'an', 'dong', 'ti',
  0x20 => 'mou', 'lei', 'yi', 'mi', 'quan', 'jin', 'po', 'wei', 'xiao', 'xie', 'hong', 'xu', 'su', 'kuang', 'tao', 'qie',
  0x30 => 'ju', 'er', 'zhou', 'ru', 'ping', 'xun', 'xiong', 'zhi', 'guang', 'huan', 'ming', 'huo', 'wa', 'qia', 'pai', 'wu',
  0x40 => 'qu', 'liu', 'yi', 'jia', 'jing', 'qian', 'jiang', 'jiao', 'zhen', 'shi', 'zhuo', 'ce', 'fa', 'hui', 'ji', 'liu',
  0x50 => 'chan', 'hun', 'hu', 'nong', 'xun', 'jin', 'lie', 'qiu', 'wei', 'zhe', 'jun', 'han', 'bang', 'mang', 'zhuo', 'you',
  0x60 => 'xi', 'bo', 'dou', 'huan', 'hong', 'yi', 'pu', 'ying', 'lan', 'hao', 'lang', 'han', 'li', 'geng', 'fu', 'wu',
  0x70 => 'lian', 'chun', 'feng', 'yi', 'yu', 'tong', 'lao', 'hai', 'jin', 'jia', 'chong', 'jiong', 'mei', 'sui', 'cheng', 'pei',
  0x80 => 'xian', 'shen', 'tu', 'kun', 'ping', 'nie', 'han', 'jing', 'xiao', 'she', 'nian', 'tu', 'yong', 'xiao', 'xian', 'ting',
  0x90 => 'e', 'su', 'tun', 'juan', 'cen', 'ti', 'li', 'shui', 'si', 'lei', 'shui', 'tao', 'du', 'lao', 'lai', 'lian',
  0xA0 => 'wei', 'wo', 'yun', 'huan', 'di', 'heng', 'run', 'jian', 'zhang', 'se', 'fu', 'guan', 'xing', 'shou', 'shuan', 'ya',
  0xB0 => 'chuo', 'zhang', 'ye', 'kong', 'wo', 'han', 'tuo', 'dong', 'he', 'wo', 'ju', 'she', 'liang', 'hun', 'ta', 'zhuo',
  0xC0 => 'dian', 'qie', 'de', 'juan', 'zi', 'xi', 'xiao', 'qi', 'gu', 'guo', 'yan', 'lin', 'tang', 'zhou', 'peng', 'hao',
  0xD0 => 'chang', 'shu', 'qi', 'fang', 'zhi', 'lu', 'nao', 'ju', 'tao', 'cong', 'lei', 'zhe', 'ping', 'fei', 'song', 'tian',
  0xE0 => 'pi', 'dan', 'yu', 'ni', 'yu', 'lu', 'gan', 'mi', 'jing', 'ling', 'lun', 'yin', 'cui', 'qu', 'huai', 'yu',
  0xF0 => 'nian', 'shen', 'biao', 'chun', 'hu', 'yuan', 'lai', 'hun', 'qing', 'yan', 'qian', 'tian', 'miao', 'zhi', 'yin', 'mi',
];
